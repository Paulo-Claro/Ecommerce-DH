export const messageErrors = {
  email: 'Já existe uma conta criada com este email!',
};