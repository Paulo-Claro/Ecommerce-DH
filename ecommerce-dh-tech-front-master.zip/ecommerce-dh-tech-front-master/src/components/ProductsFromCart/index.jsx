import { Container, Product } from "./styles"

export const ProductsFromCart = ({data, onClick}) => {
    return (
        <Container>
            <Product>
                <img src="" alt="" />
            </Product>
        </Container>
    )
}