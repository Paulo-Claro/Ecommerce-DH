import styled from "styled-components";

export const Container = styled.div`
`;

export const Product = styled.div`
    border: 1px solid gray;

`