export const mockProducts = [
    {
        id: '1',
        name: "Ryzen 5 3600G",
        description: "Processador AMD Ryzen 5 7600X, 5.3GHz Max Turbo, Cache 38MB, AM5, 6 Núcleos, Vídeo Integrado",
        price: "2.199,99",
    },
    {
        id: '2',
        name: "Ryzen 5 3600G",
        description: "Processador AMD Ryzen 5 7600X, 5.3GHz Max Turbo, Cache 38MB, AM5, 6 Núcleos, Vídeo Integrado",
        price: "2.199,99",
    },
    {
        id: '3',
        name: "Ryzen 5 3600G",
        description: "Processador AMD Ryzen 5 7600X, 5.3GHz Max Turbo, Cache 38MB, AM5, 6 Núcleos, Vídeo Integrado",
        price: "2.199,99",
    },
    {
        id: '4',
        name: "Ryzen 5 3600G",
        description: "Processador AMD Ryzen 5 7600X, 5.3GHz Max Turbo, Cache 38MB, AM5, 6 Núcleos, Vídeo Integrado",
        price: "2.199,99",
    },
    {
        id: '5',
        name: "Ryzen 5 3600G",
        description: "Processador AMD Ryzen 5 7600X, 5.3GHz Max Turbo, Cache 38MB, AM5, 6 Núcleos, Vídeo Integrado",
        price: "2.199,99",
    },
    {
        id: '6',
        name: "Ryzen 5 3600G",
        description: "Processador AMD Ryzen 5 7600X, 5.3GHz Max Turbo, Cache 38MB, AM5, 6 Núcleos, Vídeo Integrado",
        price: "2.199,99",
    },
    {
        id: '8',
        name: "Ryzen 5 3600G",
        description: "Processador AMD Ryzen 5 7600X, 5.3GHz Max Turbo, Cache 38MB, AM5, 6 Núcleos, Vídeo Integrado",
        price: "2.199,99",
    },
    {
        id: '9',
        name: "Ryzen 5 3600G",
        description: "Processador AMD Ryzen 5 7600X, 5.3GHz Max Turbo, Cache 38MB, AM5, 6 Núcleos, Vídeo Integrado",
        price: "2.199,99",
    },
    {
        id: '10',
        name: "Ryzen 5 3600G",
        description: "Processador AMD Ryzen 5 7600X, 5.3GHz Max Turbo, Cache 38MB, AM5, 6 Núcleos, Vídeo Integrado",
        price: "2.199,99",
    },


]